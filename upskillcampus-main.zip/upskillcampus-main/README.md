Dataset Link: https://www.kaggle.com/datasets/siddharthss/crop-recommendation-dataset
